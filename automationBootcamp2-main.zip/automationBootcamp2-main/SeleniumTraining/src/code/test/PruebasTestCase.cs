﻿using OpenQA.Selenium;
using SeleniumTraining.src.code.page;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SeleniumTraining.src.code.test
{
    [TestClass]
    public class PruebasTestCase : TestBase
    {

        MainPage mainPage = new MainPage();
        LoginSection loginSection = new LoginSection();
        LeftSite leftSite = new LeftSite(); 



        [TestMethod]
        public void VerifyCRUDProject()
        {
            mainPage.loginButton.Click();
            loginSection.Login("bootcamp2@mojix.com", "12345");

            // Crear un PROYECTO
            
            leftSite.addNewProjectButton.Click();
            leftSite.projectNameTxtBox.SetText("MojixMM");
            leftSite.addButton.Click();

            // add verificacion
            Assert.IsTrue(leftSite.ProjectNameIsDisplayed("MojixMM"), "ERROR!The project was not created");


            // Crear una TAREA 

            leftSite.ClickProjectName("MojixMM");
            leftSite.TaskTextBox.SetText("TareaMojixMM");
            leftSite.TaskaddButton.Click();

            // add verificacion
            Assert.IsTrue(leftSite.ProjectNameIsDisplayed("MojixMM"), "ERROR!The project was not created");


            //Modificar nombre de un PROYECTO

            leftSite.ClickProjectName("MojixMM");
            leftSite.subMenuIcon.Click();
            leftSite.editButton.Click();
            leftSite.projectNameEditTxtBox.SetText("MojixMMUpdated");
            leftSite.saveButton.Click();

            // add verificacion
            Assert.IsTrue(leftSite.ProjectNameIsDisplayed("MojixMMUpdated"), "ERROR!The project was not updated");


            //Eliminar un PROYECTO
            leftSite.ClickProjectName("MojixMMUpdated");
            leftSite.subMenuIcon.Click();
            leftSite.deleteButton.Click();

             Thread.Sleep(1000);
            session.Session.Instance().GetBrowser().SwitchTo().Alert().Accept();
             Thread.Sleep(1000);
            // add verificacion
            Assert.IsFalse(leftSite.ProjectNameIsDisplayed("MojixMMUpdated"), "ERROR!The project was not deleted");


        }

    }
}
